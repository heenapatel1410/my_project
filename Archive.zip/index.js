const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let mainWindow;
let dashboardWindow;

function createLoginWindow() {
  mainWindow = new BrowserWindow({
    width: 400,
    height: 300,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  mainWindow.loadFile('src/login.html');
  mainWindow.setMenu(null); // Disable default menu
}

function createDashboardWindow() {
  dashboardWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });

  dashboardWindow.loadFile('src/dashboard.html');
  dashboardWindow.setMenu(null);
}

app.whenReady().then(() => {
  createLoginWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createLoginWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Listen for login success and open dashboard
ipcMain.on('login-success', (event, arg) => {
  if (arg === 'success') {
    mainWindow.close(); // Close login window
    createDashboardWindow(); // Open dashboard window
  }
});
